import os
import openai
import json
import warnings
import time
from a_sheet_separator import convert_excel_to_text
from b_excel_file_creator import extract_and_save_data

# Suppress specific warnings to maintain script cleanliness.
warnings.simplefilter("ignore")

# Determine the directory where this script is located.
script_dir = os.path.dirname(__file__)

# Define the path to the configuration folder.
config_folder = os.path.join(script_dir, '1 - Config')
input_folder = os.path.join(script_dir, '2 - Excel To Text')

# Load configuration settings from a JSON file.
config_file_path = os.path.join(config_folder, 'config.json')

# Check if the configuration file exists; if not, set config as an empty dictionary.
if os.path.exists(config_file_path):
    with open(config_file_path, 'r', encoding='utf-8') as config_file:
        config = json.load(config_file)
else:
    config = {}

# Set OpenAI API key and model based on the loaded configuration.
openai.api_key = config['api_key']
model = config['model']

# Function to process an individual text file and save the second response from ChatGPT.
def process_text_file(file_path, output_folder):
    print(f"\nProcessing text file: {file_path}. This process may take up to one minute to complete.")

    # Read the content from the text file.
    with open(file_path, 'r', encoding='utf-8') as text_file:
        text_content = text_file.read()

    # Construct the first prompt for ChatGPT.
    prompt_1 = f'{config["preset_prompt_1"]} """{text_content}""".'

    response_1 = openai.ChatCompletion.create(
        model=model,
        messages=[{"role": "user", "content": prompt_1}]
    )

    # Extract the response content from response 1.
    response_1_content = response_1.choices[0].message['content']

    print("\nGenerating news articles... (This phase may take 2 to 3 minutes to complete)")

    # Construct the second prompt for ChatGPT using preset_prompt_2 and response 1 content.
    prompt_2 = f'{config["preset_prompt_2"]}"{response_1_content}".'

    # Generate the news articles using the cleaned sheets.
    response_2 = openai.ChatCompletion.create(
        model=model,
        messages=[{"role": "user", "content": prompt_2}],
        temperature=0.7  # You can adjust this temperature from values from 0.0 to 1.0, the higher the value the more creative the answer.
    )

    # Create the output folder if it doesn't exist.
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # Define the name for the output file.
    output_file_name = os.path.basename(file_path)

    # Save ChatGPT response 2 to a file in the output folder.
    result_file_path = os.path.join(output_folder, output_file_name)
    with open(result_file_path, 'w', encoding='utf-8') as result_file:
        result_file.write(response_2.choices[0].message['content'])

    print(f"\nProcessed text file: {file_path}\nNews articles generated successfully!")
    print(f"Text file saved at: {result_file_path}")

# Function to iterate through text files in a folder.
def process_text_files_in_folder(folder_path):
    text_files_found = False

    # Generator to yield subdirectories.
    subdirectories = (subdir for subdir in os.listdir(folder_path) if os.path.isdir(os.path.join(folder_path, subdir)))

    for subdirectory in subdirectories:
        subfolder_path = os.path.join(folder_path, subdirectory)
        output_folder = os.path.join(script_dir, '3 - ChatGPT Answers', subdirectory)

        for root, dirs, files in os.walk(subfolder_path):
            for file in files:
                if file.endswith('.txt'):
                    file_path = os.path.join(root, file)
                    process_text_file(file_path, output_folder)
                    text_files_found = True

    if not text_files_found:
        print(f"\nNo text files were found in any subfolder of: {folder_path}")

if __name__ == "__main__":
    print("\n---- Welcome to the TFS Python Script ----")

    print("\nPlease select the Excel files from which you want to separate the sheets.")
    time.sleep(2)
    convert_excel_to_text()

    input("\nPress Enter to begin processing the sheets files...")

    print(f"\nStarting the news article generation using the separate sheets files in the folder: {input_folder}")
    process_text_files_in_folder(input_folder)
    extract_and_save_data()
    print("\n---- News Articles generated sucessfully ----\n")