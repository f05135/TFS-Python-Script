import re
import os
import openpyxl
import warnings

# Suppress the specific warning
warnings.simplefilter("ignore")

# Get the directory where the script is located
script_dir = os.path.dirname(__file__)
input_folder = os.path.join(script_dir, '3 - ChatGPT Answers')  # Replace with your input folder

def extract_and_save_data():
    # Define the output folder where all Excel files will be saved
    output_folder = os.path.join(script_dir, "4 - Upload Files")
    os.makedirs(output_folder, exist_ok=True)

    # Initialize lists to store the extracted data
    all_headlines = []
    all_subheadlines = []
    all_bodies = []
    all_published_dates = []

    # Define the default column names
    default_columns = [
        'newsTitle', 'shortDescription', 'newsDescription', 'publishedDate','id', 'newsImageSquare', 'videoLink', 'author', 'festival', 'categories', 'isExclusive',
        'country', 'newsImageHorizontal', 'metaTitle', 'metaDescription', 'oldNewsImage',
        'trendingNewsBackgroundImage', 'createdAt', 'updatedAt', 'publishedAt'
    ]

    # Define the regular expressions for the delimiters with any number
    delimiters = {
        'Headline': r'--Headline \(\d+\) Begin--(.*?)--Headline \(\d+\) End--',
        'Subheadline': r'--Subheadline \(\d+\) Begin--(.*?)--Subheadline \(\d+\) End--',
        'Body': r'--Body \(\d+\) Begin--(.*?)--Body \(\d+\) End--',
        'publishedDate': r'--publishDate \(\d+\) Begin--(.*?)--publishDate \(\d+\) End--',
    }

    # Iterate through all the files in the input folder
    for foldername, _, filenames in os.walk(input_folder):
        # Check if the current folder or file should be skipped
        if 'A - Template Folder - (DO NOT DELETE THIS FOLDER AND ITS FILES)' in foldername:
            continue

        folder_headlines = []
        folder_subheadlines = []
        folder_bodies = []
        folder_published_dates = []

        for filename in filenames:
            if filename.endswith(".txt"):
                file_path = os.path.join(foldername, filename)

                # Read the input text file with UTF-8 encoding
                with open(file_path, 'r', encoding='utf-8') as file:
                    content = file.read()

                    # Initialize variables to store data for the current file
                    current_headlines = re.findall(delimiters['Headline'], content, re.DOTALL)
                    current_subheadlines = re.findall(delimiters['Subheadline'], content, re.DOTALL)
                    current_bodies = re.findall(delimiters['Body'], content, re.DOTALL)
                    current_published_dates = re.findall(delimiters['publishedDate'], content, re.DOTALL)

                    # Append data from the current file to the respective lists
                    folder_headlines.extend(current_headlines)
                    folder_subheadlines.extend(current_subheadlines)
                    folder_bodies.extend(current_bodies)
                    folder_published_dates.extend(current_published_dates)

        if folder_headlines or folder_subheadlines or folder_bodies or folder_published_dates:
            # Append the data for the current folder to the overall lists
            all_headlines.extend(folder_headlines)
            all_subheadlines.extend(folder_subheadlines)
            all_bodies.extend(folder_bodies)
            all_published_dates.extend(folder_published_dates)

            # Create a new Excel workbook for this folder
            workbook = openpyxl.Workbook()
            sheet = workbook.active

            # Add column headers in the first row
            sheet.append(default_columns)

            # Determine the maximum length of data lists for this folder
            max_len = max(len(folder_headlines), len(folder_subheadlines), len(folder_bodies), len(folder_published_dates))

            # Iterate through the extracted data and add it to the Excel sheet
            for i in range(max_len):
                row = [
                    folder_headlines[i] if i < len(folder_headlines) else '',
                    folder_subheadlines[i] if i < len(folder_subheadlines) else '',
                    folder_bodies[i] if i < len(folder_bodies) else '',
                    folder_published_dates[i] if i < len(folder_published_dates) else '',
                ]
                sheet.append(row)

            # Extract the base name of the current folder
            base_name = os.path.basename(foldername)
            # Remove "separated_sheet" if present in the folder name
            base_name = base_name.replace("_separated_sheet", "")
            # Create the output Excel file name for this folder
            output_excel_file = os.path.join(output_folder, f'{base_name}_articles.xlsx')

            # Save the Excel workbook for this folder
            workbook.save(output_excel_file)
            print(f"Excel File for {foldername} has been saved to {output_excel_file}.")