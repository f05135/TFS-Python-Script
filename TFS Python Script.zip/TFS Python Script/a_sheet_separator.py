import openpyxl
import os
import tkinter as tk
from tkinter import filedialog
import warnings

# Suppress the specific warning
warnings.simplefilter("ignore")

# Define the output directory (hardcoded)
output_directory = os.path.join(os.path.dirname(__file__), "2 - Excel To Text")

# Create the output directory if it doesn't exist
os.makedirs(output_directory, exist_ok=True)

# Define a list of sheets to exclude
exclude_sheets = ["Overview", "Template", "Example Festival", "All Key Dates", "Dropdowns"]

# Function to create a folder for each Excel file
def create_excel_folder(excel_filename):
    excel_folder = os.path.join(output_directory, f"{excel_filename}_separated_sheet")
    os.makedirs(excel_folder, exist_ok=True)
    return excel_folder

# Function to extract displayed value while preserving formatting
def extract_displayed_value(cell):
    if cell.data_type == "f":
        try:
            # Evaluate the formula and get the resulting value
            formula_result = cell.parent.parent.evaluate(formula=cell.value).result
            return str(formula_result) if formula_result is not None else "None"
        except Exception:
            return "None"
    if cell.data_type == "s" or cell.data_type == "str":
        return cell.value if cell.value is not None else "None"
    elif cell.data_type == "n":
        if cell.number_format and "0.00" in cell.number_format:
            return f"${cell.value:,.2f}" if cell.value is not None else "None"
        else:
            return str(cell.value) if cell.value is not None else "None"
    else:
        return str(cell.value) if cell.value is not None else "None"

# Function to extract data from a specified range with populated cells
def extract_data_from_range_with_data(sheet, start_col, end_col, start_row, end_row):
    extracted_data = []
    for row in range(start_row, end_row + 1):
        row_data = []
        row_has_data = False  # Flag to check if the row has at least one populated cell
        header_created = False  # Flag to check if the header line has been created
        for col in range(openpyxl.utils.column_index_from_string(start_col),
                         openpyxl.utils.column_index_from_string(end_col) + 1):
            cell = sheet.cell(row=row, column=col)
            cell_text = extract_displayed_value(cell)
            if cell_text != "None":
                if header_created:
                    row_data.append(cell_text)
                else:
                    if row_has_data:
                        row_data.append("\n" + cell_text)  # Add a newline before the title
                    else:
                        row_data.append(cell_text)  # Add the first non-None cell to header
                        header_created = True
                row_has_data = True
        if row_has_data:
            extracted_data.append('\t'.join(row_data))
    return extracted_data

# Function to remove a specific string from a list of strings
def remove_string_from_list(data_list, string_to_remove):
    return [line.replace(string_to_remove, '') for line in data_list]

# Function to perform the conversion using Tkinter file dialog
def convert_excel_to_text():
    # Create a Tkinter root window (hidden)
    root = tk.Tk()
    root.withdraw()  # Hide the root window

    # Use a file dialog to select multiple Excel files
    file_paths = filedialog.askopenfilenames(filetypes=[("Excel Files", "*.xlsx")])

    if not file_paths:
        print("No files selected.")
        return

    for file_path in file_paths:
        # Extract the main Excel file name without the .xlsx extension
        main_excel_file_name = os.path.splitext(os.path.basename(file_path))[0]

        # Create a folder for the current Excel file
        excel_folder = create_excel_folder(main_excel_file_name)

        # Load the Excel file
        workbook = openpyxl.load_workbook(file_path)

        # Iterate through all sheets in the workbook
        for sheet_name in workbook.sheetnames:
            if sheet_name not in exclude_sheets:
                sheet = workbook[sheet_name]

                # Extract data from columns A to E and from row 2 to 60 with populated cells
                data1 = extract_data_from_range_with_data(sheet, 'A', 'E', 2, 60)

                # Remove "00:00:00", "Updated Social Media to" from the data1
                data1 = remove_string_from_list(data1, "00:00:00")
                data1 = remove_string_from_list(data1, "Updated Social Media to")

                # Extract data from columns F to K and from row 2 to 60 with populated cells
                data2 = extract_data_from_range_with_data(sheet, 'F', 'K', 2, 60)

                # Remove "00:00:00", "Updated Social Media to" from the data2
                data2 = remove_string_from_list(data2, "00:00:00")
                data2 = remove_string_from_list(data2, "Updated Social Media to")

                # Extract data from columns L to Q and from row 2 to 200 with populated cells
                data3 = extract_data_from_range_with_data(sheet, 'L', 'Q', 2, 200)

                # Remove "00:00:00", "Updated Social Media to" from the data3
                data3 = remove_string_from_list(data3, "00:00:00")
                data3 = remove_string_from_list(data3, "Updated Social Media to")

                # Extract data from columns R to V and from row 2 to 60 with populated cells
                data4 = extract_data_from_range_with_data(sheet, 'R', 'V', 2, 60)

                # Remove "00:00:00", "Updated Social Media to" from the data4
                data4 = remove_string_from_list(data4, "00:00:00")
                data4 = remove_string_from_list(data4, "Updated Social Media to")

                # Extract data from columns W to AA and from row 2 to 60 with populated cells
                data5 = extract_data_from_range_with_data(sheet, 'W', 'AA', 2, 60)

                # Remove "00:00:00", "Updated Social Media to" from the data5
                data5 = remove_string_from_list(data5, "00:00:00")
                data5 = remove_string_from_list(data5, "Updated Social Media to")

                # Create an output file for each sheet if there is data
                if data1 or data2 or data3 or data4 or data5:
                    output_file_name = f"{sheet_name}_output.txt"
                    output_file_path = os.path.join(excel_folder, output_file_name)

                    # Add "Event: main_excel_file_name sheet_name" as the first line
                    with open(output_file_path, 'w', encoding='utf-8') as output_file:
                        # Write the header line for columns A to E
                        header_line = f"{main_excel_file_name} {sheet_name}"
                        output_file.write(header_line + "\n\n")

                        # Write the extracted data
                        if data1:
                            output_file.write('\n'.join(data1))
                            output_file.write("\n\n")
                        if data2:
                            output_file.write('\n'.join(data2))
                            output_file.write("\n\n")
                        if data3:
                            output_file.write('\n'.join(data3))
                            output_file.write("\n\n")
                        if data4:
                            output_file.write('\n'.join(data4))
                            output_file.write("\n\n")
                        if data5:
                            output_file.write('\n'.join(data5))

        # Close the Excel file
        workbook.close()